echo "sourcing magic-enter.plugin.zsh..."
plugins+=(ohmy:magic-enter)
