echo "sourcing macos.plugin.zsh..."
plugins+=(ohmy:macos)
