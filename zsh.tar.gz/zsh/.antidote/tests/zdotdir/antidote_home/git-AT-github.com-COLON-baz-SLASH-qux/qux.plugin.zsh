echo "sourcing baz/qux..."
plugins=($plugins baz/qux)
