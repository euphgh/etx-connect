echo "sourcing bar/baz..."
plugins=($plugins bar/baz)
