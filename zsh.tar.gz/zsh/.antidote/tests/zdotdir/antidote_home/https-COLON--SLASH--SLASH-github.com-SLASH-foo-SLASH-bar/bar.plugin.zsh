echo "sourcing foo/bar..."
plugins=($plugins foo/bar)
