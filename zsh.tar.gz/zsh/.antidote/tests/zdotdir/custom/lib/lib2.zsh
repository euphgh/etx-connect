echo "sourcing custom lib2.zsh..."
libs=($libs custom:lib2)
