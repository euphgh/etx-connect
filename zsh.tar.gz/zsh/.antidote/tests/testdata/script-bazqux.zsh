fpath+=( $ANTIDOTE_HOME/git-AT-github.com-COLON-baz-SLASH-qux )
source $ANTIDOTE_HOME/git-AT-github.com-COLON-baz-SLASH-qux/qux.plugin.zsh
