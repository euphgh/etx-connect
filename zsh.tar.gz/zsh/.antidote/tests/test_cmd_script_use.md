# antidote-script-use tests

## Setup

```zsh
% source ./tests/_setup.zsh
% source ./antidote.zsh
%
```

## Teardown

```zsh
% t_teardown
%
```
